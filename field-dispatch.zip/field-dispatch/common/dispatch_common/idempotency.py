"""Idempotency-Key store: first request wins, replays get the cached response."""
import json

IN_PROGRESS = "__in_progress__"


class IdempotencyStore:
    def __init__(self, redis, ttl_s: int = 86400, prefix: str = "idem:"):
        self.redis = redis
        self.ttl_s = ttl_s
        self.prefix = prefix

    def _k(self, key: str) -> str:
        return self.prefix + key

    async def begin(self, key: str) -> tuple[bool, dict | None]:
        """Returns (is_new, cached_response). cached_response is None while in progress."""
        if await self.redis.set(self._k(key), IN_PROGRESS, nx=True, ex=self.ttl_s):
            return True, None
        value = await self.redis.get(self._k(key))
        if value is None or value == IN_PROGRESS:
            return False, None
        return False, json.loads(value)

    async def complete(self, key: str, response: dict) -> None:
        await self.redis.set(self._k(key), json.dumps(response), ex=self.ttl_s)

    async def abandon(self, key: str) -> None:
        await self.redis.delete(self._k(key))
