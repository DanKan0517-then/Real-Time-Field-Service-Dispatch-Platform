"""Redis distributed lock (SET NX PX + token-checked release)."""
import asyncio
import time
import uuid

RELEASE_LUA = """
if redis.call('get', KEYS[1]) == ARGV[1] then
  return redis.call('del', KEYS[1])
else
  return 0
end
"""


class LockNotAcquired(Exception):
    pass


class RedisLock:
    def __init__(self, redis, key: str, ttl_ms: int = 5000, wait_s: float = 0.0, poll_s: float = 0.05):
        self.redis = redis
        self.key = key
        self.ttl_ms = ttl_ms
        self.wait_s = wait_s
        self.poll_s = poll_s
        self.token = uuid.uuid4().hex

    async def acquire(self) -> bool:
        deadline = time.monotonic() + self.wait_s
        while True:
            if await self.redis.set(self.key, self.token, nx=True, px=self.ttl_ms):
                return True
            if time.monotonic() >= deadline:
                return False
            await asyncio.sleep(self.poll_s)

    async def release(self) -> bool:
        # Only the holder's token can delete the key, so an expired lock re-acquired by
        # someone else is never released by mistake.
        return bool(await self.redis.eval(RELEASE_LUA, 1, self.key, self.token))

    async def __aenter__(self) -> "RedisLock":
        if not await self.acquire():
            raise LockNotAcquired(self.key)
        return self

    async def __aexit__(self, *exc) -> None:
        await self.release()
