"""Redis-backed technician availability, skills and GEO positions."""

GEO_KEY = "tech:geo"
AVAILABLE_KEY = "tech:available"
SKILL_PREFIX = "tech:skill:"
ACTIVE_JOB_KEY = "tech:active_job"


class AvailabilityTracker:
    def __init__(self, redis):
        self.redis = redis

    async def update_location(self, tech_id: str, lat: float, lon: float) -> None:
        await self.redis.geoadd(GEO_KEY, (lon, lat, tech_id))

    async def set_available(self, tech_id: str, available: bool = True) -> None:
        if available:
            await self.redis.sadd(AVAILABLE_KEY, tech_id)
        else:
            await self.redis.srem(AVAILABLE_KEY, tech_id)

    async def claim(self, tech_id: str) -> bool:
        """Atomically take a technician out of the available pool. Only one caller can win."""
        return await self.redis.srem(AVAILABLE_KEY, tech_id) == 1

    async def available_among(self, tech_ids: list[str]) -> list[str]:
        if not tech_ids:
            return []
        flags = await self.redis.smismember(AVAILABLE_KEY, tech_ids)
        return [t for t, ok in zip(tech_ids, flags) if ok]

    async def set_skills(self, tech_id: str, skills: list[str]) -> None:
        pipe = self.redis.pipeline(transaction=False)
        for s in skills:
            pipe.sadd(SKILL_PREFIX + s, tech_id)
        await pipe.execute()

    async def have_skill(self, tech_ids: list[str], skill: str) -> list[bool]:
        if not tech_ids:
            return []
        return [bool(f) for f in await self.redis.smismember(SKILL_PREFIX + skill, tech_ids)]

    async def nearby(self, lat: float, lon: float, radius_km: float, count: int) -> list[tuple[str, float]]:
        res = await self.redis.geosearch(GEO_KEY, longitude=lon, latitude=lat, radius=radius_km,
                                         unit="km", sort="ASC", count=count, withdist=True)
        return [(member, float(dist)) for member, dist in res]

    async def all_positions(self) -> list[tuple[str, float, float]]:
        members = await self.redis.zrange(GEO_KEY, 0, -1)
        if not members:
            return []
        positions = await self.redis.geopos(GEO_KEY, *members)
        return [(m, p[1], p[0]) for m, p in zip(members, positions) if p]

    async def set_active_job(self, tech_id: str, job_id: str) -> None:
        await self.redis.hset(ACTIVE_JOB_KEY, tech_id, job_id)

    async def clear_active_job(self, tech_id: str) -> None:
        await self.redis.hdel(ACTIVE_JOB_KEY, tech_id)

    async def active_job(self, tech_id: str) -> str | None:
        return await self.redis.hget(ACTIVE_JOB_KEY, tech_id)
