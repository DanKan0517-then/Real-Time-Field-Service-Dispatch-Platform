import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    kafka_bootstrap: str = os.getenv("KAFKA_BOOTSTRAP", "localhost:29092")
    redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    es_url: str = os.getenv("ES_URL", "http://localhost:9200")
    tech_index: str = os.getenv("TECH_INDEX", "technicians")


settings = Settings()
