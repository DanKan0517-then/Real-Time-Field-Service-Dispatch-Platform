"""Kafka producer + consumer loop with retries, DLQ routing and supervised restarts."""
import asyncio
import json
import logging
from collections.abc import Awaitable, Callable

from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from pydantic import ValidationError

from dispatch_common.events import DLQ_SUFFIX
from dispatch_common.resilience import with_retry

log = logging.getLogger(__name__)

Handler = Callable[[str, dict], Awaitable[None]]
DlqPublisher = Callable[[str, bytes, str | None, str], Awaitable[None]]


class EventProducer:
    def __init__(self, bootstrap: str):
        self.bootstrap = bootstrap
        self._producer: AIOKafkaProducer | None = None

    async def start(self) -> None:
        @with_retry(attempts=10, base=1.0, max_wait=5.0)
        async def _start():
            producer = AIOKafkaProducer(bootstrap_servers=self.bootstrap, acks="all",
                                        enable_idempotence=True, linger_ms=5)
            await producer.start()
            self._producer = producer

        await _start()

    async def stop(self) -> None:
        if self._producer:
            await self._producer.stop()

    async def send(self, topic: str, value: dict, key: str | None = None) -> None:
        await self._producer.send_and_wait(
            topic, json.dumps(value).encode(), key=key.encode() if key else None
        )

    async def send_raw(self, topic: str, raw: bytes, key: str | None, error: str) -> None:
        await self._producer.send_and_wait(
            topic, raw, key=key.encode() if key else None, headers=[("error", error.encode()[:1000])]
        )


async def handle_with_retries(topic: str, raw: bytes | None, key: str | None, handler: Handler, *,
                              max_retries: int = 3, dlq: DlqPublisher | None = None,
                              backoff: float = 0.2) -> bool:
    """Run handler with retries. Poison messages (bad JSON / schema) skip retries.
    Anything that still fails goes to <topic>.dlq. Returns True on success."""
    error: Exception | None = None
    for attempt in range(1, max_retries + 1):
        try:
            payload = json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError, TypeError) as exc:
            error = exc
            break
        try:
            await handler(topic, payload)
            return True
        except ValidationError as exc:
            error = exc
            break
        except Exception as exc:
            error = exc
            log.warning("handler failed topic=%s attempt=%d/%d err=%r", topic, attempt, max_retries, exc)
            if attempt < max_retries:
                await asyncio.sleep(backoff * 2 ** (attempt - 1))
    log.error("sending message to DLQ topic=%s err=%r", topic, error)
    if dlq is not None:
        await dlq(topic + DLQ_SUFFIX, raw or b"", key, repr(error))
    return False


async def run_consumer(topics: list[str], group_id: str | None, handler: Handler, bootstrap: str, *,
                       dlq: DlqPublisher | None = None, max_retries: int = 3,
                       auto_offset_reset: str = "earliest") -> None:
    consumer = AIOKafkaConsumer(
        *topics,
        bootstrap_servers=bootstrap,
        group_id=group_id,
        enable_auto_commit=False,
        auto_offset_reset=auto_offset_reset,
    )
    await consumer.start()
    log.info("consumer started topics=%s group=%s", topics, group_id)
    try:
        async for msg in consumer:
            key = msg.key.decode() if msg.key else None
            await handle_with_retries(msg.topic, msg.value, key, handler, max_retries=max_retries, dlq=dlq)
            if group_id:
                # Commit only after handling (or DLQ) -> at-least-once delivery.
                await consumer.commit()
    finally:
        await consumer.stop()


async def supervise(factory: Callable[[], Awaitable[None]], name: str, max_backoff: float = 30.0) -> None:
    """Restart a crashed consumer with exponential backoff."""
    backoff = 1.0
    while True:
        try:
            await factory()
            return
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("%s crashed; restarting in %.1fs", name, backoff)
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, max_backoff)
