"""Shared building blocks for the field dispatch services."""
