"""Circuit breaker + retry policy helpers."""
import time
from collections.abc import Awaitable, Callable
from typing import Any

from tenacity import (
    retry,
    retry_if_exception_type,
    retry_if_not_exception_type,
    stop_after_attempt,
    wait_exponential_jitter,
)


class CircuitOpenError(Exception):
    """Raised when a call is short-circuited because the breaker is open."""


class CircuitBreaker:
    """Closed -> (N consecutive failures) -> Open -> (reset_timeout) -> Half-open -> one trial call.

    A successful trial closes the breaker; a failed trial re-opens it.
    """

    def __init__(self, name: str, failure_threshold: int = 5, reset_timeout: float = 10.0,
                 clock: Callable[[], float] = time.monotonic):
        self.name = name
        self.failure_threshold = failure_threshold
        self.reset_timeout = reset_timeout
        self._clock = clock
        self._failures = 0
        self._opened_at: float | None = None
        self._trial_in_flight = False

    @property
    def state(self) -> str:
        if self._opened_at is None:
            return "closed"
        if self._clock() - self._opened_at >= self.reset_timeout:
            return "half_open"
        return "open"

    async def call(self, fn: Callable[..., Awaitable[Any]], *args: Any, **kwargs: Any) -> Any:
        state = self.state
        if state == "open":
            raise CircuitOpenError(self.name)
        is_trial = state == "half_open"
        if is_trial:
            if self._trial_in_flight:
                raise CircuitOpenError(self.name)
            self._trial_in_flight = True
        try:
            result = await fn(*args, **kwargs)
        except Exception:
            self._on_failure()
            raise
        finally:
            if is_trial:
                self._trial_in_flight = False
        self._on_success()
        return result

    def _on_failure(self) -> None:
        self._failures += 1
        if self._opened_at is not None or self._failures >= self.failure_threshold:
            self._opened_at = self._clock()

    def _on_success(self) -> None:
        self._failures = 0
        self._opened_at = None


def with_retry(attempts: int = 3, base: float = 0.1, max_wait: float = 2.0,
               retry_on: tuple[type[BaseException], ...] = (Exception,)):
    """Exponential backoff with jitter. Never retries an open circuit."""
    return retry(
        stop=stop_after_attempt(attempts),
        wait=wait_exponential_jitter(initial=base, max=max_wait),
        retry=retry_if_exception_type(retry_on) & retry_if_not_exception_type(CircuitOpenError),
        reraise=True,
    )
