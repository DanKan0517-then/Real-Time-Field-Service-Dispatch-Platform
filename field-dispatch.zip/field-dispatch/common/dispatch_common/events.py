import time
import uuid
from typing import Literal

from pydantic import BaseModel, Field

TOPIC_LOCATION = "technician.location"
TOPIC_JOB = "job.events"
DLQ_SUFFIX = ".dlq"


class LocationUpdate(BaseModel):
    technician_id: str = Field(min_length=1, max_length=64)
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    ts: float = Field(default_factory=time.time)


class JobEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    type: Literal["job.created", "job.assigned", "job.status_changed"]
    job_id: str
    technician_id: str | None = None
    status: str | None = None
    ts: float = Field(default_factory=time.time)
