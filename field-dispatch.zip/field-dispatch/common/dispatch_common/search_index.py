from elasticsearch import AsyncElasticsearch, BadRequestError

from dispatch_common.resilience import with_retry

TECH_MAPPINGS = {
    "properties": {
        "technician_id": {"type": "keyword"},
        "location": {"type": "geo_point"},
        "skills": {"type": "keyword"},
        "status": {"type": "keyword"},
        "updated_at": {"type": "date", "format": "epoch_millis"},
    }
}


@with_retry(attempts=10, base=1.0, max_wait=5.0)
async def ensure_tech_index(es: AsyncElasticsearch, index: str) -> None:
    if await es.indices.exists(index=index):
        return
    try:
        await es.indices.create(
            index=index,
            mappings=TECH_MAPPINGS,
            settings={"number_of_shards": 1, "number_of_replicas": 0, "refresh_interval": "1s"},
        )
    except BadRequestError as exc:
        if "resource_already_exists_exception" not in str(exc):
            raise
