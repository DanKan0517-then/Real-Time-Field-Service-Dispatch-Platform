import logging
import time
import uuid
from contextlib import asynccontextmanager
from typing import Annotated, Literal

from elasticsearch import AsyncElasticsearch
from fastapi import FastAPI, Header, HTTPException, Query, Request
from pydantic import BaseModel, Field
from redis.asyncio import Redis

from dispatch_common.availability import AvailabilityTracker
from dispatch_common.config import settings
from dispatch_common.events import TOPIC_JOB, JobEvent
from dispatch_common.idempotency import IdempotencyStore
from dispatch_common.kafka import EventProducer
from dispatch_common.locks import LockNotAcquired, RedisLock
from dispatch_common.search_index import ensure_tech_index

from app.search import es_breaker, find_candidates, naive_scan

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("dispatch")

JOB_TRANSITIONS: dict[str, set[str]] = {
    "pending": {"assigned", "cancelled"},
    "assigned": {"en_route", "cancelled"},
    "en_route": {"on_site", "cancelled"},
    "on_site": {"completed"},
    "completed": set(),
    "cancelled": set(),
}


class CreateJob(BaseModel):
    customer_id: str = Field(min_length=1, max_length=64)
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    skill: str = Field(min_length=1, max_length=32)
    priority: int = Field(default=3, ge=1, le=5)


class StatusUpdate(BaseModel):
    status: Literal["en_route", "on_site", "completed", "cancelled"]


@asynccontextmanager
async def lifespan(app: FastAPI):
    redis = Redis.from_url(settings.redis_url, decode_responses=True)
    es = AsyncElasticsearch(settings.es_url)
    producer = EventProducer(settings.kafka_bootstrap)
    await producer.start()
    await ensure_tech_index(es, settings.tech_index)
    app.state.redis = redis
    app.state.es = es
    app.state.producer = producer
    app.state.avail = AvailabilityTracker(redis)
    app.state.idem = IdempotencyStore(redis)
    log.info("dispatch service ready")
    yield
    await producer.stop()
    await es.close()
    await redis.aclose()


app = FastAPI(title="Dispatch Service", version="0.1.0", lifespan=lifespan)


def job_key(job_id: str) -> str:
    return f"job:{job_id}"


async def load_job(redis, job_id: str) -> dict:
    raw = await redis.hgetall(job_key(job_id))
    if not raw:
        raise HTTPException(404, "Job not found")
    return {**raw, "lat": float(raw["lat"]), "lon": float(raw["lon"]), "priority": int(raw["priority"])}


async def publish(request: Request, event: JobEvent) -> None:
    await request.app.state.producer.send(TOPIC_JOB, event.model_dump(mode="json"), key=event.job_id)


@app.get("/health")
async def health():
    return {"status": "ok", "elasticsearch_breaker": es_breaker.state}


@app.post("/jobs", status_code=201)
async def create_job(body: CreateJob, request: Request,
                     idempotency_key: Annotated[str, Header(alias="Idempotency-Key", min_length=8)]):
    st = request.app.state
    is_new, cached = await st.idem.begin(idempotency_key)
    if not is_new:
        if cached is None:
            raise HTTPException(409, "A request with this Idempotency-Key is still in progress")
        return cached
    try:
        job_id = uuid.uuid4().hex
        job = {"job_id": job_id, "status": "pending", "technician_id": "", **body.model_dump()}
        await st.redis.hset(job_key(job_id), mapping={k: str(v) for k, v in job.items()})
        await publish(request, JobEvent(type="job.created", job_id=job_id, status="pending"))
    except Exception:
        await st.idem.abandon(idempotency_key)
        raise
    await st.idem.complete(idempotency_key, job)
    return job


@app.get("/jobs/{job_id}")
async def get_job(job_id: str, request: Request):
    return await load_job(request.app.state.redis, job_id)


@app.post("/jobs/{job_id}/assign")
async def assign_job(job_id: str, request: Request, radius_km: float = Query(15, gt=0, le=200)):
    """Assign the nearest available, skill-matching technician.
    Job-level distributed lock prevents concurrent assignment of the same job;
    atomic SREM claim prevents a technician being double-booked across jobs."""
    st = request.app.state
    try:
        async with RedisLock(st.redis, f"lock:job:{job_id}", ttl_ms=5000, wait_s=0.5):
            job = await load_job(st.redis, job_id)
            if job["status"] == "assigned":
                return job  # retry-safe
            if job["status"] != "pending":
                raise HTTPException(409, f"Job is {job['status']}")
            t0 = time.perf_counter()
            candidates, source = await find_candidates(
                st.es, st.avail, job["lat"], job["lon"], radius_km, job["skill"], limit=10
            )
            for c in candidates:
                tech_id = c["technician_id"]
                if not await st.avail.claim(tech_id):
                    continue  # someone else just took this technician
                try:
                    await st.redis.hset(job_key(job_id), mapping={"status": "assigned", "technician_id": tech_id})
                    await publish(request, JobEvent(type="job.assigned", job_id=job_id,
                                                    technician_id=tech_id, status="assigned"))
                except Exception:
                    # compensate so the technician and job are not stuck
                    await st.avail.set_available(tech_id, True)
                    await st.redis.hset(job_key(job_id), mapping={"status": "pending", "technician_id": ""})
                    raise
                job.update(status="assigned", technician_id=tech_id, distance_km=c["distance_km"],
                           search_source=source, assign_ms=round((time.perf_counter() - t0) * 1000, 2))
                return job
            raise HTTPException(503, "No available technician within radius")
    except LockNotAcquired:
        raise HTTPException(409, "Job is being assigned by another request")


@app.post("/jobs/{job_id}/status")
async def update_status(job_id: str, body: StatusUpdate, request: Request):
    st = request.app.state
    try:
        async with RedisLock(st.redis, f"lock:job:{job_id}", ttl_ms=5000, wait_s=0.5):
            job = await load_job(st.redis, job_id)
            previous = job["status"]
            if body.status not in JOB_TRANSITIONS.get(previous, set()):
                raise HTTPException(409, f"Cannot move job from {previous} to {body.status}")
            await st.redis.hset(job_key(job_id), "status", body.status)
            try:
                await publish(request, JobEvent(type="job.status_changed", job_id=job_id,
                                                technician_id=job["technician_id"] or None, status=body.status))
            except Exception:
                await st.redis.hset(job_key(job_id), "status", previous)
                raise
            job["status"] = body.status
            return job
    except LockNotAcquired:
        raise HTTPException(409, "Job is locked by another request")


@app.get("/technicians/search")
async def search_technicians(
    request: Request,
    lat: float = Query(ge=-90, le=90),
    lon: float = Query(ge=-180, le=180),
    radius_km: float = Query(10, gt=0, le=200),
    skill: str | None = None,
    limit: int = Query(20, ge=1, le=100),
    strategy: Literal["indexed", "naive"] = "indexed",
):
    st = request.app.state
    t0 = time.perf_counter()
    if strategy == "naive":
        results, source = await naive_scan(st.avail, lat, lon, radius_km, skill, limit), "naive-scan"
    else:
        results, source = await find_candidates(st.es, st.avail, lat, lon, radius_km, skill, limit)
    return {"source": source, "took_ms": round((time.perf_counter() - t0) * 1000, 2), "results": results}
