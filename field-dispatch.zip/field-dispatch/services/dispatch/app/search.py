"""Technician candidate search: Elasticsearch geo query, Redis GEO fallback, naive baseline."""
import logging
import math

from elasticsearch import AsyncElasticsearch

from dispatch_common.availability import AvailabilityTracker
from dispatch_common.config import settings
from dispatch_common.resilience import CircuitBreaker, with_retry

log = logging.getLogger(__name__)
es_breaker = CircuitBreaker("elasticsearch", failure_threshold=5, reset_timeout=10.0)
OVERFETCH = 3  # fetch extra hits because some nearby technicians will be busy


@with_retry(attempts=2, base=0.05, max_wait=0.2)
async def _es_geo_search(es: AsyncElasticsearch, lat: float, lon: float, radius_km: float,
                         skill: str | None, size: int) -> list[tuple[str, float]]:
    filters: list[dict] = [
        {"geo_distance": {"distance": f"{radius_km}km", "location": {"lat": lat, "lon": lon}}}
    ]
    if skill:
        filters.append({"term": {"skills": skill}})
    resp = await es.options(request_timeout=1.0).search(
        index=settings.tech_index,
        size=size,
        query={"bool": {"filter": filters}},
        sort=[{"_geo_distance": {"location": {"lat": lat, "lon": lon}, "order": "asc", "unit": "km"}}],
        source=False,
    )
    return [(h["_id"], float(h["sort"][0])) for h in resp["hits"]["hits"]]


async def _redis_geo_fallback(avail: AvailabilityTracker, lat: float, lon: float, radius_km: float,
                              skill: str | None, size: int) -> list[tuple[str, float]]:
    hits = await avail.nearby(lat, lon, radius_km, size)
    if skill:
        flags = await avail.have_skill([h[0] for h in hits], skill)
        hits = [h for h, ok in zip(hits, flags) if ok]
    return hits


async def _filter_available(avail, hits, limit):
    available = set(await avail.available_among([h[0] for h in hits]))
    return [{"technician_id": t, "distance_km": round(d, 3)} for t, d in hits if t in available][:limit]


async def find_candidates(es, avail, lat, lon, radius_km, skill, limit) -> tuple[list[dict], str]:
    try:
        hits = await es_breaker.call(_es_geo_search, es, lat, lon, radius_km, skill, limit * OVERFETCH)
        source = "elasticsearch"
    except Exception as exc:
        log.warning("ES unavailable (%s); falling back to Redis GEO", type(exc).__name__)
        hits = await _redis_geo_fallback(avail, lat, lon, radius_km, skill, limit * OVERFETCH)
        source = "redis-geo-fallback"
    return await _filter_available(avail, hits, limit), source


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 6371.0088 * 2 * math.asin(math.sqrt(a))


async def naive_scan(avail, lat, lon, radius_km, skill, limit) -> list[dict]:
    """Baseline for benchmarking: load every technician and compute distance in Python."""
    positions = await avail.all_positions()
    hits = [(t, haversine_km(lat, lon, la, lo)) for t, la, lo in positions]
    hits = sorted((h for h in hits if h[1] <= radius_km), key=lambda h: h[1])
    if skill:
        flags = await avail.have_skill([h[0] for h in hits], skill)
        hits = [h for h, ok in zip(hits, flags) if ok]
    return await _filter_available(avail, hits, limit)
