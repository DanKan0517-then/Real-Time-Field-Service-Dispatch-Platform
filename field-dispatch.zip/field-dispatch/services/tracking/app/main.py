import asyncio
import contextlib
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field, ValidationError
from redis.asyncio import Redis

from dispatch_common.availability import AvailabilityTracker
from dispatch_common.config import settings
from dispatch_common.events import TOPIC_JOB, TOPIC_LOCATION, LocationUpdate
from dispatch_common.kafka import EventProducer, run_consumer, supervise
from dispatch_common.resilience import CircuitBreaker, CircuitOpenError, with_retry

from app.ws import ConnectionManager

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("tracking")
kafka_breaker = CircuitBreaker("kafka-producer", failure_threshold=5, reset_timeout=5.0)


class LocationIn(BaseModel):
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)


def make_fanout_handler(manager: ConnectionManager, avail: AvailabilityTracker):
    async def handle(topic: str, payload: dict) -> None:
        if topic == TOPIC_LOCATION:
            msg = {"type": "technician.location", **payload}
            await manager.broadcast("dispatch", msg)
            job_id = await avail.active_job(payload.get("technician_id", ""))
            if job_id:
                await manager.broadcast(f"job:{job_id}", msg)
        elif topic == TOPIC_JOB:
            await manager.broadcast("dispatch", payload)
            await manager.broadcast(f"job:{payload.get('job_id')}", payload)

    return handle


@asynccontextmanager
async def lifespan(app: FastAPI):
    redis = Redis.from_url(settings.redis_url, decode_responses=True)
    producer = EventProducer(settings.kafka_bootstrap)
    await producer.start()
    manager = ConnectionManager()
    handler = make_fanout_handler(manager, AvailabilityTracker(redis))
    # group_id=None: every tracking instance sees every event so it can serve its own sockets.
    task = asyncio.create_task(supervise(
        lambda: run_consumer([TOPIC_LOCATION, TOPIC_JOB], None, handler, settings.kafka_bootstrap,
                             auto_offset_reset="latest"),
        "tracking-fanout",
    ))
    app.state.redis, app.state.producer, app.state.manager = redis, producer, manager
    yield
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task
    await producer.stop()
    await redis.aclose()


app = FastAPI(title="Tracking Service", version="0.1.0", lifespan=lifespan)


@with_retry(attempts=3, base=0.05, max_wait=0.5)
async def _send_location(producer: EventProducer, evt: LocationUpdate) -> None:
    # key = technician_id keeps each technician's updates ordered within one partition
    await producer.send(TOPIC_LOCATION, evt.model_dump(mode="json"), key=evt.technician_id)


async def publish_location(producer: EventProducer, evt: LocationUpdate) -> None:
    await kafka_breaker.call(_send_location, producer, evt)


@app.get("/health")
async def health(request: Request):
    return {"status": "ok", "kafka_breaker": kafka_breaker.state,
            "websocket_connections": request.app.state.manager.count()}


@app.post("/technicians/{technician_id}/location", status_code=202)
async def post_location(technician_id: str, body: LocationIn, request: Request):
    evt = LocationUpdate(technician_id=technician_id, lat=body.lat, lon=body.lon)
    try:
        await publish_location(request.app.state.producer, evt)
    except CircuitOpenError:
        raise HTTPException(503, "Location pipeline temporarily unavailable, retry shortly")
    return {"accepted": True}


@app.websocket("/ws/technicians/{technician_id}")
async def technician_stream(ws: WebSocket, technician_id: str):
    """Technician app streams GPS fixes: {"lat": .., "lon": ..}"""
    await ws.accept()
    try:
        while True:
            data = await ws.receive_json()
            try:
                evt = LocationUpdate.model_validate({**data, "technician_id": technician_id})
            except (ValidationError, TypeError):
                await ws.send_json({"error": "invalid location payload"})
                continue
            try:
                await publish_location(ws.app.state.producer, evt)
            except Exception:
                await ws.send_json({"error": "temporarily unavailable, resend later"})
    except WebSocketDisconnect:
        pass


async def _subscribe(ws: WebSocket, channel: str) -> None:
    manager: ConnectionManager = ws.app.state.manager
    await manager.connect(channel, ws)
    try:
        while True:
            await ws.receive_text()  # keep-alive; client messages are ignored
    except WebSocketDisconnect:
        manager.disconnect(channel, ws)


@app.websocket("/ws/jobs/{job_id}")
async def job_stream(ws: WebSocket, job_id: str):
    """Customer / dispatcher view of one job: status changes + assigned technician's location."""
    await _subscribe(ws, f"job:{job_id}")


@app.websocket("/ws/dispatch")
async def dispatch_stream(ws: WebSocket):
    """Dispatcher console: every location + job event."""
    await _subscribe(ws, "dispatch")
