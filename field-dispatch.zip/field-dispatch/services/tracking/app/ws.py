import asyncio
from collections import defaultdict

from fastapi import WebSocket


class ConnectionManager:
    """Channel-based WebSocket fan-out. Slow or dead sockets are dropped, never block others."""

    def __init__(self, send_timeout: float = 1.0):
        self._channels: dict[str, set[WebSocket]] = defaultdict(set)
        self.send_timeout = send_timeout

    async def connect(self, channel: str, ws: WebSocket) -> None:
        await ws.accept()
        self._channels[channel].add(ws)

    def disconnect(self, channel: str, ws: WebSocket) -> None:
        conns = self._channels.get(channel)
        if conns is None:
            return
        conns.discard(ws)
        if not conns:
            del self._channels[channel]

    def count(self) -> int:
        return sum(len(c) for c in self._channels.values())

    async def _send(self, ws: WebSocket, message: dict) -> bool:
        try:
            await asyncio.wait_for(ws.send_json(message), timeout=self.send_timeout)
            return True
        except Exception:
            return False

    async def broadcast(self, channel: str, message: dict) -> None:
        conns = list(self._channels.get(channel, ()))
        if not conns:
            return
        results = await asyncio.gather(*(self._send(ws, message) for ws in conns))
        for ws, ok in zip(conns, results):
            if not ok:
                self.disconnect(channel, ws)
