"""Consumes location + job events and keeps Redis (availability/GEO) and Elasticsearch in sync."""
import asyncio
import contextlib
import logging
import signal

from elasticsearch import AsyncElasticsearch
from redis.asyncio import Redis

from dispatch_common.availability import AvailabilityTracker
from dispatch_common.config import settings
from dispatch_common.events import TOPIC_JOB, TOPIC_LOCATION, JobEvent, LocationUpdate
from dispatch_common.kafka import EventProducer, run_consumer, supervise
from dispatch_common.resilience import CircuitBreaker, with_retry
from dispatch_common.search_index import ensure_tech_index

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("indexer")
es_breaker = CircuitBreaker("elasticsearch-writes", failure_threshold=5, reset_timeout=10.0)


class Indexer:
    def __init__(self, redis, es: AsyncElasticsearch, avail: AvailabilityTracker):
        self.redis = redis
        self.es = es
        self.avail = avail

    async def handle(self, topic: str, payload: dict) -> None:
        if topic == TOPIC_LOCATION:
            evt = LocationUpdate.model_validate(payload)
            # Redis first: keeps the GEO fallback path fresh even if ES is down.
            await self.avail.update_location(evt.technician_id, evt.lat, evt.lon)
            await self._es_upsert(evt.technician_id, {
                "technician_id": evt.technician_id,
                "location": {"lat": evt.lat, "lon": evt.lon},
                "updated_at": int(evt.ts * 1000),
            })
        elif topic == TOPIC_JOB:
            evt = JobEvent.model_validate(payload)
            dedupe_key = f"processed:indexer:{evt.event_id}"
            if await self.redis.exists(dedupe_key):
                return  # duplicate delivery (at-least-once)
            await self._apply_job_event(evt)
            await self.redis.set(dedupe_key, 1, ex=86400)

    async def _apply_job_event(self, evt: JobEvent) -> None:
        tech_id = evt.technician_id
        if not tech_id:
            return
        if evt.type == "job.assigned":
            await self.avail.set_active_job(tech_id, evt.job_id)
            await self._es_upsert(tech_id, {"status": "busy"})
        elif evt.type == "job.status_changed" and evt.status in ("completed", "cancelled"):
            await self.avail.clear_active_job(tech_id)
            await self.avail.set_available(tech_id, True)
            await self._es_upsert(tech_id, {"status": "available"})

    async def _es_upsert(self, tech_id: str, doc: dict) -> None:
        await es_breaker.call(self._es_update, tech_id, doc)

    @with_retry(attempts=3, base=0.1, max_wait=1.0)
    async def _es_update(self, tech_id: str, doc: dict) -> None:
        await self.es.update(index=settings.tech_index, id=tech_id, doc=doc, doc_as_upsert=True)


async def main() -> None:
    redis = Redis.from_url(settings.redis_url, decode_responses=True)
    es = AsyncElasticsearch(settings.es_url)
    await ensure_tech_index(es, settings.tech_index)
    producer = EventProducer(settings.kafka_bootstrap)
    await producer.start()
    indexer = Indexer(redis, es, AvailabilityTracker(redis))

    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)

    task = asyncio.create_task(supervise(
        lambda: run_consumer([TOPIC_LOCATION, TOPIC_JOB], "indexer", indexer.handle,
                             settings.kafka_bootstrap, dlq=producer.send_raw),
        "indexer-consumer",
    ))
    log.info("indexer running")
    await stop.wait()
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task
    await producer.stop()
    await es.close()
    await redis.aclose()


if __name__ == "__main__":
    asyncio.run(main())
