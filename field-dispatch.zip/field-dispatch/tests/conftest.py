import pytest
from fakeredis import FakeAsyncRedis


@pytest.fixture
async def redis():
    r = FakeAsyncRedis(decode_responses=True)
    await r.flushall()
    yield r
    await r.flushall()
    await r.aclose()
