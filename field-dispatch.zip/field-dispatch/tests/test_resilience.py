import pytest

from dispatch_common.resilience import CircuitBreaker, CircuitOpenError


class FakeClock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


async def boom():
    raise RuntimeError("down")


async def ok():
    return "ok"


async def _trip(cb):
    for _ in range(cb.failure_threshold):
        with pytest.raises(RuntimeError):
            await cb.call(boom)


async def test_opens_after_threshold():
    cb = CircuitBreaker("t", failure_threshold=2, reset_timeout=5, clock=FakeClock())
    await _trip(cb)
    assert cb.state == "open"
    with pytest.raises(CircuitOpenError):
        await cb.call(ok)


async def test_half_open_success_closes():
    clock = FakeClock()
    cb = CircuitBreaker("t", failure_threshold=2, reset_timeout=5, clock=clock)
    await _trip(cb)
    clock.t = 5
    assert cb.state == "half_open"
    assert await cb.call(ok) == "ok"
    assert cb.state == "closed"


async def test_half_open_failure_reopens():
    clock = FakeClock()
    cb = CircuitBreaker("t", failure_threshold=2, reset_timeout=5, clock=clock)
    await _trip(cb)
    clock.t = 5
    with pytest.raises(RuntimeError):
        await cb.call(boom)
    assert cb.state == "open"
