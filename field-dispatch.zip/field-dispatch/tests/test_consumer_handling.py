from unittest.mock import AsyncMock

from pydantic import BaseModel

from dispatch_common.kafka import handle_with_retries


async def test_retries_then_succeeds():
    calls = {"n": 0}

    async def handler(topic, payload):
        calls["n"] += 1
        if calls["n"] < 3:
            raise RuntimeError("transient")

    dlq = AsyncMock()
    assert await handle_with_retries("t", b'{"a": 1}', None, handler, max_retries=3, dlq=dlq, backoff=0)
    assert calls["n"] == 3
    dlq.assert_not_called()


async def test_exhausted_retries_go_to_dlq():
    handler = AsyncMock(side_effect=RuntimeError("down"))
    dlq = AsyncMock()
    assert not await handle_with_retries("t", b"{}", "k", handler, max_retries=3, dlq=dlq, backoff=0)
    assert handler.await_count == 3
    assert dlq.await_args.args[0] == "t.dlq"


async def test_poison_message_is_not_retried():
    handler = AsyncMock()
    dlq = AsyncMock()
    assert not await handle_with_retries("t", b"not json", None, handler, dlq=dlq, backoff=0)
    handler.assert_not_called()
    dlq.assert_awaited_once()


async def test_schema_violation_is_not_retried():
    class Model(BaseModel):
        x: int

    calls = {"n": 0}

    async def handler(topic, payload):
        calls["n"] += 1
        Model.model_validate(payload)

    dlq = AsyncMock()
    assert not await handle_with_retries("t", b'{"x": "nope"}', None, handler, dlq=dlq, backoff=0)
    assert calls["n"] == 1
