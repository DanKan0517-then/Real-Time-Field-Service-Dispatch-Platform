from dispatch_common.idempotency import IdempotencyStore


async def test_first_request_wins_and_replay_is_cached(redis):
    store = IdempotencyStore(redis)
    assert await store.begin("k1") == (True, None)
    assert await store.begin("k1") == (False, None)  # in progress
    await store.complete("k1", {"job_id": "j1"})
    assert await store.begin("k1") == (False, {"job_id": "j1"})


async def test_abandon_allows_retry(redis):
    store = IdempotencyStore(redis)
    await store.begin("k2")
    await store.abandon("k2")
    assert await store.begin("k2") == (True, None)
