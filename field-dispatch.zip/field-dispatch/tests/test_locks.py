import pytest

from dispatch_common.locks import LockNotAcquired, RedisLock


async def test_mutual_exclusion_and_safe_release(redis):
    a = RedisLock(redis, "lock:x", ttl_ms=1000)
    b = RedisLock(redis, "lock:x", ttl_ms=1000)
    assert await a.acquire()
    assert not await b.acquire()
    assert not await b.release()  # b must not release a's lock
    assert await a.release()
    assert await b.acquire()


async def test_context_manager_raises_when_held(redis):
    async with RedisLock(redis, "lock:y"):
        with pytest.raises(LockNotAcquired):
            async with RedisLock(redis, "lock:y", wait_s=0.1):
                pass
