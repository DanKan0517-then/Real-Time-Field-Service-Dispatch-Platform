import asyncio

from dispatch_common.availability import AvailabilityTracker


async def test_claim_is_exclusive_under_concurrency(redis):
    t = AvailabilityTracker(redis)
    await t.set_available("tech-1")
    results = await asyncio.gather(*(t.claim("tech-1") for _ in range(20)))
    assert results.count(True) == 1


async def test_available_among_and_skills(redis):
    t = AvailabilityTracker(redis)
    await t.set_available("a")
    await t.set_available("b")
    await t.set_available("b", False)
    await t.set_skills("a", ["hvac"])
    assert await t.available_among(["a", "b", "c"]) == ["a"]
    assert await t.have_skill(["a", "b"], "hvac") == [True, False]


async def test_nearby_sorted_by_distance(redis):
    t = AvailabilityTracker(redis)
    await t.update_location("far", 13.20, 77.70)
    await t.update_location("near", 12.972, 77.595)
    hits = await t.nearby(12.9716, 77.5946, 50, 10)
    assert [h[0] for h in hits] == ["near", "far"]
