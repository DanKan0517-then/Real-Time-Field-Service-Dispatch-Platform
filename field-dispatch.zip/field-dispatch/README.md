# 🛠️ Real-Time Field Service Dispatch Platform

[![CI/CD](https://github.com/DanKan0517-then/field-dispatch/actions/workflows/ci.yml/badge.svg)](https://github.com/DanKan0517-then/field-dispatch/actions/workflows/ci.yml)
![Python](https://img.shields.io/badge/Python-3.12-blue)
![FastAPI](https://img.shields.io/badge/FastAPI-microservices-009688)
![Kafka](https://img.shields.io/badge/Kafka-event--driven-black)
![Redis](https://img.shields.io/badge/Redis-locks%20%26%20availability-red)
![Elasticsearch](https://img.shields.io/badge/Elasticsearch-geo%20search-yellow)

A distributed backend that **finds the nearest available technician for a service request, assigns them safely under heavy concurrency, and streams their live location and job status** to dispatchers and customers in real time.

Built to handle **10,000+ technicians** and **100,000+ service requests**.

---

## ✨ What it does

| Step | What happens |
|---|---|
| 1. Customer raises a request | `POST /jobs` creates a job. An **Idempotency-Key** makes sure a retried request never creates a duplicate job. |
| 2. System finds technicians | Elasticsearch **geo search** finds technicians near the job with the right skill; Redis filters out anyone busy. |
| 3. Job gets assigned | A **distributed lock** on the job plus an **atomic claim** on the technician guarantee no double assignment. |
| 4. Technician moves | The technician app streams GPS over **WebSocket**; updates flow through **Kafka**. |
| 5. Everyone sees it live | Dispatchers and customers receive live location + status updates over **WebSockets**. |

---

## 🏗️ Architecture

```mermaid
flowchart LR
    TA[📱 Technician app] -- GPS via WebSocket / REST --> TR[tracking-service :8001]
    TR -- technician.location --> K[(Kafka)]
    CL[👤 Customer / Ops] -- REST --> DS[dispatch-service :8000]
    DS -- job.events --> K
    DS -- geo search --> ES[(Elasticsearch)]
    DS -- locks · idempotency · availability --> R[(Redis)]
    K --> IX[indexer worker]
    IX -- update location & status --> ES
    IX -- GEO + availability --> R
    IX -. failed messages .-> DLQ[(*.dlq topics)]
    K --> TR
    TR -- live updates --> WS[🖥️ Dispatcher & customer WebSockets]
```

| Service | Port | Responsibility |
|---|---|---|
| **dispatch** | 8000 | Create jobs, search technicians, assign nearest available, manage job status |
| **tracking** | 8001 | Receive technician GPS, broadcast location & job updates over WebSockets |
| **indexer** | – | Kafka consumer that keeps Elasticsearch and Redis in sync, with retries and a dead-letter queue |

---

## 🧰 Tech stack

| Layer | Technology | Why |
|---|---|---|
| API | **FastAPI** (async Python 3.12) | High-throughput async I/O, auto-generated docs |
| Messaging | **Apache Kafka** (KRaft mode) | Durable, ordered event streams per technician / job |
| Cache & coordination | **Redis 7** | Availability sets, GEO index, distributed locks, idempotency keys |
| Search | **Elasticsearch 8** | `geo_point` distance filtering and sorting at scale |
| Real-time | **WebSockets** | Push location & status to clients instantly |
| Resilience | Custom circuit breaker + **tenacity** retries | Survive downstream outages gracefully |
| DevOps | **Docker Compose**, **GitHub Actions**, **GHCR** | One-command local stack, automated test → integration → publish |

---

## 🧠 How the hard problems are solved

- **Fast technician search** — technicians are `geo_point` docs in Elasticsearch; `geo_distance` filter + `_geo_distance` sort, then filtered against Redis availability with one `SMISMEMBER` call. `?strategy=naive` gives a full-scan baseline to measure the speed-up.
- **No double assignments** — a Redis lock per job (`SET NX PX` + token-checked Lua release) and an atomic `SREM` claim per technician: if 20 requests race for one technician, exactly one wins.
- **Safe retries** — `POST /jobs` requires `Idempotency-Key`; replays return the same job, concurrent duplicates get `409`.
- **Reliable events** — messages keyed per technician/job for ordering, offsets committed only after handling (at-least-once), exponential-backoff retries, poison messages to `<topic>.dlq`, event-id dedupe, auto-restarting consumers.
- **Fault tolerance** — circuit breakers on Elasticsearch and Kafka; if ES is down, search falls back to Redis `GEOSEARCH`; failed assignment events are rolled back.

---

## 📁 Project structure

```
field-dispatch/
├── common/dispatch_common/      # Shared library (locks, idempotency, availability, kafka, resilience)
├── services/
│   ├── dispatch/                # Job + assignment API
│   ├── tracking/                # GPS ingest + WebSocket fan-out
│   └── indexer/                 # Kafka → Elasticsearch/Redis sync worker
├── scripts/                     # seed.py, bench.py, smoke.sh
├── tests/                       # Unit tests
├── .github/workflows/ci.yml     # CI/CD pipeline
└── docker-compose.yml           # Full local stack
```

---

## 🚀 Getting started

**Prerequisites:** Docker + Compose v2, Python 3.11+, ~3 GB free RAM.

```bash
git clone https://github.com/DanKan0517-then/field-dispatch.git
cd field-dispatch
docker compose up -d --build --wait              # start everything
pip install -e common -r requirements-dev.txt
python scripts/seed.py --count 10000 --reset     # 10K technicians around Bengaluru
bash scripts/smoke.sh                            # should end with: smoke test passed
```

API docs: http://localhost:8000/docs (dispatch) · http://localhost:8001/docs (tracking)

Stop with `docker compose down -v`.

---

## 📡 API reference

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/jobs` | Create a job (header `Idempotency-Key` required) |
| `GET` | `/jobs/{job_id}` | Get a job |
| `POST` | `/jobs/{job_id}/assign?radius_km=15` | Assign nearest available technician |
| `POST` | `/jobs/{job_id}/status` | `en_route`, `on_site`, `completed`, `cancelled` |
| `GET` | `/technicians/search?lat=&lon=&radius_km=&skill=` | Find nearby available technicians |
| `POST` | `:8001/technicians/{id}/location` | Send one GPS update |

```bash
curl -X POST localhost:8000/jobs -H "Idempotency-Key: $(uuidgen)" -H "Content-Type: application/json" \
  -d '{"customer_id":"c-42","lat":12.97,"lon":77.59,"skill":"plumbing"}'
curl -X POST "localhost:8000/jobs/<job_id>/assign?radius_km=10"
```

### WebSockets

| URL | Receives |
|---|---|
| `ws://localhost:8001/ws/dispatch` | Every location + job event |
| `ws://localhost:8001/ws/jobs/{job_id}` | That job's status + its technician's location |
| `ws://localhost:8001/ws/technicians/{tech_id}` | Technician sends `{"lat": .., "lon": ..}` |

---

## 🔄 Job lifecycle

```mermaid
stateDiagram-v2
    [*] --> pending
    pending --> assigned
    pending --> cancelled
    assigned --> en_route
    assigned --> cancelled
    en_route --> on_site
    en_route --> cancelled
    on_site --> completed
```

---

## 📊 Benchmarks

```bash
python scripts/bench.py --searches 5000 --jobs 2000 --concurrency 50
```

| Scenario | Requests | Mean (ms) | p50 | p95 | p99 |
|---|---|---|---|---|---|
| Search — naive scan | | | | | |
| Search — ES geo + Redis | | | | | |
| Assign (lock + claim + event) | | | | | |

> Fill in with your own run. Results depend on hardware.

---

## ✅ Testing & CI/CD

`ruff check .` and `pytest -q` run the lint and unit tests (circuit breaker, locks, idempotency, concurrent claims, Kafka retry/DLQ).

GitHub Actions: **lint + unit tests → full Docker integration test (seed, smoke, benchmark) → publish images to GHCR** on `main`.

---

## 🩺 Troubleshooting

| Problem | Fix |
|---|---|
| Elasticsearch exits | Give Docker ≥ 4 GB, or on Linux `sudo sysctl -w vm.max_map_count=262144` |
| `503 No available technician` | Run the seed script or increase `radius_km` |
| Search shows `redis-geo-fallback` | Elasticsearch is down/starting; breaker switched to Redis |

---

## 👤 Author

**Dhanushkanth Balasubramanian** — [@DanKan0517-then](https://github.com/DanKan0517-then)
