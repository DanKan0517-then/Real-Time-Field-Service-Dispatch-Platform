#!/usr/bin/env bash
# End-to-end check: create (idempotent) -> assign -> status update
set -euo pipefail
BASE=${BASE:-http://localhost:8000}
KEY=$(python -c 'import uuid;print(uuid.uuid4().hex)')
BODY='{"customer_id":"c-1","lat":12.9716,"lon":77.5946,"skill":"hvac"}'

JOB_ID=$(curl -fsS -X POST "$BASE/jobs" -H "Idempotency-Key: $KEY" -H 'Content-Type: application/json' -d "$BODY" | jq -r .job_id)
REPLAY_ID=$(curl -fsS -X POST "$BASE/jobs" -H "Idempotency-Key: $KEY" -H 'Content-Type: application/json' -d "$BODY" | jq -r .job_id)
[ "$JOB_ID" = "$REPLAY_ID" ] || { echo "idempotency check failed"; exit 1; }
echo "created job $JOB_ID (replay returned same job)"

TECH=$(curl -fsS -X POST "$BASE/jobs/$JOB_ID/assign?radius_km=25" | jq -r .technician_id)
[ -n "$TECH" ] && [ "$TECH" != "null" ] || { echo "assignment failed"; exit 1; }
echo "assigned technician $TECH"

curl -fsS -X POST "$BASE/jobs/$JOB_ID/status" -H 'Content-Type: application/json' -d '{"status":"en_route"}' >/dev/null
curl -fsS -X POST "http://localhost:8001/technicians/$TECH/location" -H 'Content-Type: application/json' \
  -d '{"lat":12.9720,"lon":77.5950}' >/dev/null
echo "smoke test passed"
