"""Latency benchmark: indexed geo search vs naive full scan, and create+assign under concurrency.

    python scripts/bench.py --searches 2000 --jobs 1000 --concurrency 50
"""
import argparse
import asyncio
import random
import statistics
import time
import uuid

import httpx

SKILLS = ["hvac", "plumbing", "electrical", "appliance", "network"]


def pct(values: list[float], p: float) -> float:
    s = sorted(values)
    return s[max(0, min(len(s) - 1, round(p / 100 * (len(s) - 1))))]


def row(name: str, lat: list[float]) -> str:
    if not lat:
        return f"| {name} | 0 | - | - | - | - |"
    return (f"| {name} | {len(lat)} | {statistics.mean(lat):.1f} | {pct(lat, 50):.1f} | "
            f"{pct(lat, 95):.1f} | {pct(lat, 99):.1f} |")


def random_point(rng, args):
    return (args.lat + rng.uniform(-args.spread, args.spread),
            args.lon + rng.uniform(-args.spread, args.spread))


async def bench_search(client, args, strategy, rng):
    sem, lat = asyncio.Semaphore(args.concurrency), []

    async def one():
        la, lo = random_point(rng, args)
        params = {"lat": la, "lon": lo, "radius_km": 5, "skill": rng.choice(SKILLS), "strategy": strategy}
        async with sem:
            t0 = time.perf_counter()
            r = await client.get("/technicians/search", params=params)
            lat.append((time.perf_counter() - t0) * 1000)
            r.raise_for_status()

    await asyncio.gather(*(one() for _ in range(args.searches)))
    return lat


async def bench_assign(client, args, rng):
    sem, lat, failures = asyncio.Semaphore(args.concurrency), [], 0

    async def one():
        nonlocal failures
        la, lo = random_point(rng, args)
        body = {"customer_id": f"c-{rng.randint(1, 10**6)}", "lat": la, "lon": lo, "skill": rng.choice(SKILLS)}
        async with sem:
            r = await client.post("/jobs", json=body, headers={"Idempotency-Key": uuid.uuid4().hex})
            r.raise_for_status()
            job_id = r.json()["job_id"]
            t0 = time.perf_counter()
            r = await client.post(f"/jobs/{job_id}/assign", params={"radius_km": 10})
            lat.append((time.perf_counter() - t0) * 1000)
            if r.status_code != 200:
                failures += 1

    await asyncio.gather(*(one() for _ in range(args.jobs)))
    return lat, failures


async def main(args):
    rng = random.Random(7)
    async with httpx.AsyncClient(base_url=args.base, timeout=30) as client:
        naive = await bench_search(client, args, "naive", rng)
        indexed = await bench_search(client, args, "indexed", rng)
        assign, failures = await bench_assign(client, args, rng)
    print("| scenario | n | mean ms | p50 | p95 | p99 |\n|---|---|---|---|---|---|")
    print(row("search: naive scan", naive))
    print(row("search: ES geo + Redis availability", indexed))
    print(row("assign (lock + claim + event)", assign))
    print(f"\nassign failures (no technician / conflict): {failures}")
    if naive and indexed:
        print(f"p95 search latency reduction: {(1 - pct(indexed, 95) / pct(naive, 95)) * 100:.1f}%")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--base", default="http://localhost:8000")
    p.add_argument("--searches", type=int, default=1000)
    p.add_argument("--jobs", type=int, default=500)
    p.add_argument("--concurrency", type=int, default=50)
    p.add_argument("--lat", type=float, default=12.9716)
    p.add_argument("--lon", type=float, default=77.5946)
    p.add_argument("--spread", type=float, default=0.15)
    asyncio.run(main(p.parse_args()))
