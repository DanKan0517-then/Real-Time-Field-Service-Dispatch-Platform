"""Seed N technicians into Elasticsearch + Redis around a city centre (default: Bengaluru)."""
import argparse
import asyncio
import random
import time

from elasticsearch import AsyncElasticsearch
from elasticsearch.helpers import async_bulk
from redis.asyncio import Redis

from dispatch_common.availability import ACTIVE_JOB_KEY, AVAILABLE_KEY, GEO_KEY, SKILL_PREFIX
from dispatch_common.search_index import ensure_tech_index

SKILLS = ["hvac", "plumbing", "electrical", "appliance", "network"]


async def main(args: argparse.Namespace) -> None:
    es = AsyncElasticsearch(args.es)
    redis = Redis.from_url(args.redis, decode_responses=True)
    if args.reset:
        await es.options(ignore_status=404).indices.delete(index=args.index)
        await redis.delete(GEO_KEY, AVAILABLE_KEY, ACTIVE_JOB_KEY, *[SKILL_PREFIX + s for s in SKILLS])
    await ensure_tech_index(es, args.index)

    rng = random.Random(42)
    now_ms = int(time.time() * 1000)
    docs = []
    pipe = redis.pipeline(transaction=False)
    for i in range(args.count):
        tid = f"tech-{i:05d}"
        lat = args.lat + rng.uniform(-args.spread, args.spread)
        lon = args.lon + rng.uniform(-args.spread, args.spread)
        skills = rng.sample(SKILLS, k=rng.randint(1, 3))
        docs.append({"_index": args.index, "_id": tid, "_source": {
            "technician_id": tid, "location": {"lat": lat, "lon": lon},
            "skills": skills, "status": "available", "updated_at": now_ms}})
        pipe.geoadd(GEO_KEY, (lon, lat, tid))
        pipe.sadd(AVAILABLE_KEY, tid)
        for s in skills:
            pipe.sadd(SKILL_PREFIX + s, tid)
    t0 = time.perf_counter()
    await pipe.execute()
    await async_bulk(es, docs, chunk_size=2000, refresh=True)
    print(f"seeded {args.count} technicians in {time.perf_counter() - t0:.1f}s")
    await es.close()
    await redis.aclose()


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--count", type=int, default=10_000)
    p.add_argument("--lat", type=float, default=12.9716)
    p.add_argument("--lon", type=float, default=77.5946)
    p.add_argument("--spread", type=float, default=0.15, help="degrees (~16 km)")
    p.add_argument("--es", default="http://localhost:9200")
    p.add_argument("--redis", default="redis://localhost:6379/0")
    p.add_argument("--index", default="technicians")
    p.add_argument("--reset", action="store_true")
    asyncio.run(main(p.parse_args()))
